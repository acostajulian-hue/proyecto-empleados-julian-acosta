-- ============================================================
-- NOMBRE: 09_seguridad_permisos.sql
-- DESCRIPCIÓN: Seguridad y permisos de la base de datos
-- ============================================================

-- Crear usuarios de la base de datos
-- CREATE USER 'admin_empleados'@'localhost' IDENTIFIED BY 'password_seguro';
-- CREATE USER 'supervisor_empleados'@'localhost' IDENTIFIED BY 'password_seguro';
-- CREATE USER 'user_empleados'@'localhost' IDENTIFIED BY 'password_seguro';

-- Asignar permisos (ejemplo)
-- GRANT ALL PRIVILEGES ON control_empleados.* TO 'admin_empleados'@'localhost';
-- GRANT SELECT, INSERT, UPDATE ON control_empleados.empleados TO 'supervisor_empleados'@'localhost';
-- GRANT SELECT ON control_empleados.* TO 'user_empleados'@'localhost';

-- Ver permisos actuales
SHOW GRANTS FOR 'root'@'localhost';

-- Revocar permisos
-- REVOKE DELETE ON control_empleados.empleados FROM 'supervisor_empleados'@'localhost';