-- ============================================================
-- NOMBRE: 04_procedimientos_almacenados.sql
-- DESCRIPCIÓN: Todos los procedimientos almacenados
-- ============================================================

-- Procedimiento 1: Registrar entrada
DELIMITER //

CREATE PROCEDURE sp_registrar_entrada(
    IN p_empleado_id INT
)
BEGIN
    DECLARE v_existe INT;
    
    SELECT COUNT(*) INTO v_existe 
    FROM asistencias 
    WHERE empleado_id = p_empleado_id AND fecha = CURDATE();
    
    IF v_existe = 0 THEN
        INSERT INTO asistencias (empleado_id, fecha, hora_entrada, estado) 
        VALUES (p_empleado_id, CURDATE(), CURTIME(), 'Presente');
        SELECT '✅ Entrada registrada exitosamente' AS mensaje;
    ELSE
        SELECT '❌ El empleado ya tiene entrada registrada hoy' AS mensaje;
    END IF;
END //

DELIMITER ;

-- Procedimiento 2: Registrar salida
DELIMITER //

CREATE PROCEDURE sp_registrar_salida(
    IN p_empleado_id INT
)
BEGIN
    DECLARE v_existe INT;
    
    SELECT COUNT(*) INTO v_existe 
    FROM asistencias 
    WHERE empleado_id = p_empleado_id AND fecha = CURDATE() AND hora_entrada IS NOT NULL;
    
    IF v_existe > 0 THEN
        UPDATE asistencias 
        SET hora_salida = CURTIME() 
        WHERE empleado_id = p_empleado_id AND fecha = CURDATE();
        SELECT '✅ Salida registrada exitosamente' AS mensaje;
    ELSE
        SELECT '❌ No se encontró entrada para hoy' AS mensaje;
    END IF;
END //

DELIMITER ;

-- Procedimiento 3: Buscar empleados
DELIMITER //

CREATE PROCEDURE sp_buscar_empleados(
    IN p_termino VARCHAR(100)
)
BEGIN
    SELECT 
        e.id,
        CONCAT(e.nombre, ' ', e.apellido) AS empleado,
        e.dni,
        e.cargo,
        a.nombre AS area,
        e.salario
    FROM empleados e
    LEFT JOIN areas a ON e.area_id = a.id
    WHERE e.activo = 1
    AND (
        e.nombre LIKE CONCAT('%', p_termino, '%')
        OR e.apellido LIKE CONCAT('%', p_termino, '%')
        OR e.dni LIKE CONCAT('%', p_termino, '%')
    )
    ORDER BY e.apellido, e.nombre;
END //

DELIMITER ;

-- Procedimiento 4: Reporte de asistencias por rango de fechas
DELIMITER //

CREATE PROCEDURE sp_reporte_asistencias(
    IN p_fecha_inicio DATE,
    IN p_fecha_fin DATE
)
BEGIN
    SELECT 
        CONCAT(e.nombre, ' ', e.apellido) AS empleado,
        a.fecha,
        TIME_FORMAT(a.hora_entrada, '%H:%i') AS entrada,
        TIME_FORMAT(a.hora_salida, '%H:%i') AS salida,
        a.estado,
        a.observaciones
    FROM asistencias a
    JOIN empleados e ON a.empleado_id = e.id
    WHERE a.fecha BETWEEN p_fecha_inicio AND p_fecha_fin
    ORDER BY a.fecha DESC, e.apellido;
END //

DELIMITER ;

-- Procedimiento 5: Estadísticas generales
DELIMITER //

CREATE PROCEDURE sp_estadisticas_generales()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM empleados WHERE activo = 1) AS total_empleados,
        (SELECT COUNT(*) FROM areas) AS total_areas,
        (SELECT COUNT(*) FROM asistencias WHERE fecha = CURDATE()) AS asistencias_hoy,
        (SELECT COUNT(DISTINCT empleado_id) FROM asistencias WHERE fecha = CURDATE()) AS empleados_presentes_hoy,
        (SELECT ROUND(AVG(salario), 2) FROM empleados WHERE activo = 1) AS salario_promedio,
        (SELECT MAX(salario) FROM empleados WHERE activo = 1) AS salario_maximo,
        (SELECT MIN(salario) FROM empleados WHERE activo = 1) AS salario_minimo;
END //

DELIMITER ;