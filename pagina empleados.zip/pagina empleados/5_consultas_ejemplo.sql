-- ============================================================
-- NOMBRE: 05_consultas_ejemplo.sql
-- DESCRIPCIÓN: Consultas de ejemplo para pruebas
-- ============================================================

-- Ver todas las tablas
SHOW TABLES;

-- Ver estructura de cada tabla
DESCRIBE areas;
DESCRIBE empleados;
DESCRIBE asistencias;
DESCRIBE usuarios;

-- Ver datos de todas las tablas
SELECT * FROM areas;
SELECT * FROM empleados;
SELECT * FROM asistencias;
SELECT * FROM usuarios;

-- Ver vistas
SELECT * FROM v_empleados_area;
SELECT * FROM v_resumen_asistencias;
SELECT * FROM v_asistencias_hoy;
SELECT * FROM v_empleados_por_area;
SELECT * FROM v_top_salarios;
SELECT * FROM v_antiguedad;
SELECT * FROM v_ausentes_hoy;
SELECT * FROM v_asistencias_mes_actual;

-- Consultas personalizadas
SELECT * FROM v_empleados_area WHERE area = 'Desarrollo';
SELECT * FROM v_empleados_area WHERE salario > 250000;
SELECT * FROM v_asistencias_hoy WHERE estado = 'Tarde';
SELECT * FROM v_antiguedad LIMIT 5;
SELECT * FROM v_resumen_asistencias WHERE id = 1;

-- Asistencias de un empleado en los últimos 10 días
SELECT * FROM asistencias 
WHERE empleado_id = 1 
AND fecha >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)
ORDER BY fecha DESC;

-- Empleados sin asistencia hoy
SELECT * FROM v_ausentes_hoy;

-- Llamar a procedimientos
CALL sp_estadisticas_generales();
CALL sp_buscar_empleados('González');
CALL sp_reporte_asistencias(DATE_SUB(CURDATE(), INTERVAL 7 DAY), CURDATE());
CALL sp_registrar_entrada(1);
CALL sp_registrar_salida(1);