-- ============================================================
-- NOMBRE: 02_insertar_datos_prueba.sql
-- DESCRIPCIÓN: Datos de prueba para todas las tablas
-- ============================================================

INSERT INTO areas (nombre, descripcion) VALUES
('Desarrollo', 'Equipo de programación y desarrollo de software'),
('Soporte Técnico', 'Atención de incidencias y mantenimiento de sistemas'),
('Administración', 'Gestión financiera, recursos humanos y legales'),
('Ventas', 'Comercialización, marketing y atención al cliente'),
('Calidad', 'Control de calidad y testing de software');

INSERT INTO empleados 
(nombre, apellido, dni, fecha_nac, cargo, salario, fecha_ingreso, email, telefono, direccion, area_id) 
VALUES
('Carlos', 'González', '30123456', '1985-03-15', 'Desarrollador Senior', 350000.00, '2020-01-10', 'carlos.g@tecno.com', '1156789012', 'Av. Corrientes 1234', 1),
('María', 'López', '32123456', '1990-07-22', 'Analista Funcional', 280000.00, '2021-06-01', 'maria.l@tecno.com', '1167890123', 'Calle Florida 567', 1),
('Juan', 'Pérez', '34123456', '1988-11-05', 'Técnico Soporte', 220000.00, '2019-03-15', 'juan.p@tecno.com', '1178901234', 'Av. Santa Fe 890', 2),
('Ana', 'Martínez', '35123456', '1992-09-30', 'Administrativa', 250000.00, '2022-02-20', 'ana.m@tecno.com', '1189012345', 'Calle Libertad 321', 3),
('Roberto', 'Fernández', '36123456', '1983-05-12', 'Ejecutivo de Ventas', 300000.00, '2018-11-01', 'roberto.f@tecno.com', '1190123456', 'Av. Pueyrredón 456', 4),
('Laura', 'García', '37123456', '1995-12-08', 'Desarrolladora Jr', 180000.00, '2023-04-10', 'laura.g@tecno.com', '1201234567', 'Calle Arenales 789', 1),
('Diego', 'Rodríguez', '38123456', '1987-08-25', 'Supervisor Soporte', 270000.00, '2020-07-01', 'diego.r@tecno.com', '1212345678', 'Av. Cabildo 101', 2),
('Patricia', 'Suárez', '39123456', '1991-02-14', 'Responsable de Calidad', 290000.00, '2021-09-15', 'patricia.s@tecno.com', '1223456789', 'Calle Bulnes 234', 5),
('Martín', 'Gómez', '40123456', '1989-06-20', 'Desarrollador', 200000.00, '2022-08-01', 'martin.g@tecno.com', '1234567890', 'Av. Luro 567', 1),
('Lucía', 'Fernández', '41123456', '1993-10-10', 'Administrativa', 230000.00, '2023-01-15', 'lucia.f@tecno.com', '1245678901', 'Calle Olavarria 890', 3),
('Santiago', 'Díaz', '42123456', '1986-04-25', 'Técnico Soporte', 210000.00, '2021-11-01', 'santiago.d@tecno.com', '1256789012', 'Av. Alem 123', 2),
('Valentina', 'Torres', '43123456', '1994-07-18', 'Vendedora', 190000.00, '2023-03-01', 'valentina.t@tecno.com', '1267890123', 'Calle Salta 456', 4);

INSERT INTO asistencias (empleado_id, fecha, hora_entrada, hora_salida, estado) VALUES
(1, CURDATE(), '08:30:00', '17:30:00', 'Presente'),
(2, CURDATE(), '09:00:00', '18:00:00', 'Presente'),
(3, CURDATE(), '08:45:00', '17:15:00', 'Presente'),
(4, CURDATE(), '08:00:00', '16:00:00', 'Presente'),
(5, CURDATE(), '09:30:00', '18:30:00', 'Tarde'),
(6, CURDATE(), '08:20:00', '17:20:00', 'Presente'),
(7, CURDATE(), '08:10:00', '17:10:00', 'Presente'),
(8, CURDATE(), '08:00:00', '16:30:00', 'Presente'),
(9, CURDATE(), '08:50:00', '17:50:00', 'Presente'),
(10, CURDATE(), '08:15:00', '16:15:00', 'Presente'),
(11, CURDATE(), '09:15:00', '18:15:00', 'Tarde'),
(12, CURDATE(), '08:05:00', '16:05:00', 'Presente');

INSERT INTO usuarios (empleado_id, username, password, rol) VALUES
(1, 'cgonzalez', 'admin123', 'admin'),
(2, 'mlopez', 'super123', 'supervisor'),
(3, 'jperez', 'user123', 'user'),
(4, 'amartinez', 'user456', 'user'),
(5, 'rfernandez', 'user789', 'user');