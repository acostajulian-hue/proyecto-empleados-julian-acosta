-- ============================================================
-- NOMBRE: 11_script_completo.sql
-- DESCRIPCIÓN: Script completo - TODO EN UNO
-- EJECUTAR ESTO EN phpMyAdmin O MySQL Workbench
-- ============================================================

-- 1. Crear base de datos
DROP DATABASE IF EXISTS control_empleados;
CREATE DATABASE control_empleados CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE control_empleados;

-- 2. Crear tablas
CREATE TABLE areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE empleados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    dni VARCHAR(15) NOT NULL UNIQUE,
    fecha_nac DATE,
    cargo VARCHAR(50),
    salario DECIMAL(10,2),
    fecha_ingreso DATE NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(20),
    direccion VARCHAR(150),
    area_id INT,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE SET NULL
);

CREATE TABLE asistencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT NOT NULL,
    fecha DATE NOT NULL,
    hora_entrada TIME,
    hora_salida TIME,
    estado ENUM('Presente', 'Ausente', 'Justificado', 'Tarde', 'Vacaciones') DEFAULT 'Presente',
    observaciones TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE CASCADE,
    UNIQUE KEY unique_asistencia (empleado_id, fecha)
);

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'supervisor', 'user') DEFAULT 'user',
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE SET NULL
);

CREATE TABLE logs_eliminacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50),
    registro_id INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50)
);

-- 3. Insertar datos
INSERT INTO areas (nombre, descripcion) VALUES
('Desarrollo', 'Equipo de programación'),
('Soporte Técnico', 'Atención de incidencias'),
('Administración', 'Gestión financiera y RRHH'),
('Ventas', 'Comercialización'),
('Calidad', 'Control de calidad');

INSERT INTO empleados (nombre, apellido, dni, fecha_nac, cargo, salario, fecha_ingreso, email, telefono, direccion, area_id) VALUES
('Carlos', 'González', '30123456', '1985-03-15', 'Desarrollador Senior', 350000.00, '2020-01-10', 'carlos.g@tecno.com', '1156789012', 'Av. Corrientes 1234', 1),
('María', 'López', '32123456', '1990-07-22', 'Analista Funcional', 280000.00, '2021-06-01', 'maria.l@tecno.com', '1167890123', 'Calle Florida 567', 1),
('Juan', 'Pérez', '34123456', '1988-11-05', 'Técnico Soporte', 220000.00, '2019-03-15', 'juan.p@tecno.com', '1178901234', 'Av. Santa Fe 890', 2),
('Ana', 'Martínez', '35123456', '1992-09-30', 'Administrativa', 250000.00, '2022-02-20', 'ana.m@tecno.com', '1189012345', 'Calle Libertad 321', 3),
('Roberto', 'Fernández', '36123456', '1983-05-12', 'Ejecutivo de Ventas', 300000.00, '2018-11-01', 'roberto.f@tecno.com', '1190123456', 'Av. Pueyrredón 456', 4);

INSERT INTO asistencias (empleado_id, fecha, hora_entrada, hora_salida, estado) VALUES
(1, CURDATE(), '08:30:00', '17:30:00', 'Presente'),
(2, CURDATE(), '09:00:00', '18:00:00', 'Presente'),
(3, CURDATE(), '08:45:00', '17:15:00', 'Presente'),
(4, CURDATE(), '08:00:00', '16:00:00', 'Presente'),
(5, CURDATE(), '09:30:00', '18:30:00', 'Tarde');

INSERT INTO usuarios (empleado_id, username, password, rol) VALUES
(1, 'cgonzalez', 'admin123', 'admin'),
(2, 'mlopez', 'super123', 'supervisor'),
(3, 'jperez', 'user123', 'user');

-- 4. Crear vistas
CREATE VIEW v_empleados_area AS
SELECT e.*, a.nombre AS area, DATEDIFF(CURDATE(), e.fecha_ingreso) AS dias_antiguedad
FROM empleados e LEFT JOIN areas a ON e.area_id = a.id WHERE e.activo = 1;

CREATE VIEW v_resumen_asistencias AS
SELECT e.id, e.nombre, e.apellido,
    COUNT(a.id) AS total_asistencias,
    SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
    SUM(CASE WHEN a.estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
    SUM(CASE WHEN a.estado = 'Tarde' THEN 1 ELSE 0 END) AS tardes
FROM empleados e LEFT JOIN asistencias a ON e.id = a.empleado_id
WHERE e.activo = 1 GROUP BY e.id;

CREATE VIEW v_asistencias_hoy AS
SELECT a.id, CONCAT(e.nombre, ' ', e.apellido) AS empleado, e.dni,
    TIME_FORMAT(a.hora_entrada, '%H:%i') AS entrada,
    TIME_FORMAT(a.hora_salida, '%H:%i') AS salida, a.estado
FROM asistencias a JOIN empleados e ON a.empleado_id = e.id
WHERE a.fecha = CURDATE() ORDER BY a.hora_entrada DESC;

CREATE VIEW v_empleados_por_area AS
SELECT a.nombre AS area, COUNT(e.id) AS cantidad, ROUND(AVG(e.salario), 2) AS salario_promedio
FROM areas a LEFT JOIN empleados e ON a.id = e.area_id AND e.activo = 1
GROUP BY a.id ORDER BY cantidad DESC;

CREATE VIEW v_top_salarios AS
SELECT CONCAT(e.nombre, ' ', e.apellido) AS empleado, e.cargo, e.salario, a.nombre AS area
FROM empleados e LEFT JOIN areas a ON e.area_id = a.id
WHERE e.activo = 1 AND e.salario IS NOT NULL
ORDER BY e.salario DESC LIMIT 5;

CREATE VIEW v_antiguedad AS
SELECT CONCAT(e.nombre, ' ', e.apellido) AS empleado, e.cargo, e.fecha_ingreso,
    CONCAT(FLOOR(DATEDIFF(CURDATE(), e.fecha_ingreso) / 365), ' años, ',
    FLOOR((DATEDIFF(CURDATE(), e.fecha_ingreso) % 365) / 30), ' meses') AS antiguedad
FROM empleados e WHERE e.activo = 1 ORDER BY DATEDIFF(CURDATE(), e.fecha_ingreso) DESC;

-- 5. Verificar todo
SELECT '✅ BASE DE DATOS CREADA EXITOSAMENTE' AS mensaje;
SHOW TABLES;
SELECT '✅ DATOS CARGADOS' AS mensaje;
SELECT 'Empleados:' AS tabla, COUNT(*) AS cantidad FROM empleados
UNION SELECT 'Áreas:', COUNT(*) FROM areas
UNION SELECT 'Asistencias:', COUNT(*) FROM asistencias
UNION SELECT 'Usuarios:', COUNT(*) FROM usuarios;