-- ============================================================
-- NOMBRE: 06_gestion_usuarios.sql
-- DESCRIPCIÓN: Consultas para gestión de usuarios
-- ============================================================

-- Listar todos los usuarios
SELECT 
    u.id,
    u.username,
    u.rol,
    u.activo,
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.dni,
    e.cargo
FROM usuarios u
LEFT JOIN empleados e ON u.empleado_id = e.id
ORDER BY u.username;

-- Crear un nuevo usuario
INSERT INTO usuarios (empleado_id, username, password, rol) 
VALUES (5, 'rfernandez', 'user789', 'user');

-- Cambiar contraseña
UPDATE usuarios SET password = 'nueva_clave123' WHERE username = 'cgonzalez';

-- Cambiar rol de usuario
UPDATE usuarios SET rol = 'supervisor' WHERE username = 'jperez';

-- Desactivar usuario
UPDATE usuarios SET activo = 0 WHERE username = 'usuario_inactivo';

-- Activar usuario
UPDATE usuarios SET activo = 1 WHERE username = 'usuario_reactivado';

-- Eliminar usuario
DELETE FROM usuarios WHERE username = 'usuario_a_eliminar';

-- Verificar credenciales (para login)
SELECT 
    u.*,
    CONCAT(e.nombre, ' ', e.apellido) AS nombre_completo
FROM usuarios u
LEFT JOIN empleados e ON u.empleado_id = e.id
WHERE u.username = 'cgonzalez' 
AND u.password = 'admin123' 
AND u.activo = 1;

-- Contar usuarios por rol
SELECT 
    rol,
    COUNT(*) AS cantidad,
    SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) AS activos
FROM usuarios
GROUP BY rol;