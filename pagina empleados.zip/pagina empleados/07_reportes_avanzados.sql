-- ============================================================
-- NOMBRE: 07_reportes_avanzados.sql
-- DESCRIPCIÓN: Reportes avanzados para la documentación
-- ============================================================

-- 1. Distribución de salarios por área
SELECT 
    a.nombre AS area,
    COUNT(e.id) AS cantidad,
    ROUND(AVG(e.salario), 2) AS promedio,
    ROUND(MIN(e.salario), 2) AS minimo,
    ROUND(MAX(e.salario), 2) AS maximo,
    ROUND(SUM(e.salario), 2) AS total
FROM areas a
LEFT JOIN empleados e ON a.id = e.area_id AND e.activo = 1
GROUP BY a.id
HAVING cantidad > 0
ORDER BY promedio DESC;

-- 2. Porcentaje de presentismo mensual
SELECT 
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    MONTH(a.fecha) AS mes,
    YEAR(a.fecha) AS año,
    COUNT(a.id) AS dias_trabajados,
    SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
    ROUND(
        (SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 2
    ) AS porcentaje_presentismo
FROM empleados e
JOIN asistencias a ON e.id = a.empleado_id
WHERE e.activo = 1
GROUP BY e.id, YEAR(a.fecha), MONTH(a.fecha)
ORDER BY año DESC, mes DESC, porcentaje_presentismo DESC;

-- 3. Empleados que más tardes acumulan
SELECT 
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    COUNT(a.id) AS total_tardes,
    e.cargo,
    a2.nombre AS area
FROM empleados e
JOIN asistencias a ON e.id = a.empleado_id
JOIN areas a2 ON e.area_id = a2.id
WHERE a.estado = 'Tarde'
GROUP BY e.id
ORDER BY total_tardes DESC
LIMIT 10;

-- 4. Evolución de asistencias por mes
SELECT 
    DATE_FORMAT(fecha, '%Y-%m') AS mes,
    COUNT(*) AS total_asistencias,
    SUM(CASE WHEN estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
    SUM(CASE WHEN estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
    SUM(CASE WHEN estado = 'Tarde' THEN 1 ELSE 0 END) AS tardes
FROM asistencias
GROUP BY DATE_FORMAT(fecha, '%Y-%m')
ORDER BY mes DESC;

-- 5. Rangos salariales
SELECT 
    CASE 
        WHEN salario < 200000 THEN 'Menos de $200.000'
        WHEN salario BETWEEN 200000 AND 300000 THEN '$200.000 - $300.000'
        WHEN salario BETWEEN 300001 AND 400000 THEN '$300.001 - $400.000'
        WHEN salario > 400000 THEN 'Más de $400.000'
        ELSE 'Sin salario'
    END AS rango_salarial,
    COUNT(*) AS cantidad,
    ROUND(AVG(salario), 2) AS promedio
FROM empleados
WHERE activo = 1
GROUP BY rango_salarial
ORDER BY MIN(salario);

-- 6. Carga de trabajo por área
SELECT 
    a2.nombre AS area,
    COUNT(a.id) AS total_asistencias,
    COUNT(DISTINCT a.empleado_id) AS empleados_activos,
    ROUND(COUNT(a.id) / COUNT(DISTINCT a.empleado_id), 2) AS promedio_por_empleado
FROM asistencias a
JOIN empleados e ON a.empleado_id = e.id
JOIN areas a2 ON e.area_id = a2.id
WHERE MONTH(a.fecha) = MONTH(CURDATE()) 
AND YEAR(a.fecha) = YEAR(CURDATE())
GROUP BY a2.id
ORDER BY promedio_por_empleado DESC;