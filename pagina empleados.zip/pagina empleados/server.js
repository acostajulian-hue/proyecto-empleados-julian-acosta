// ============================================================
// NOMBRE: server.js
// DESCRIPCIÓN: Servidor Node.js con Express + MySQL
// ============================================================

const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// CONFIGURACIÓN DEL SERVIDOR
// ============================================================

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Configuración de sesiones
app.use(session({
    secret: process.env.SESSION_SECRET || 'mi_clave_secreta',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 1000 * 60 * 60 * 24 // 24 horas
    }
}));

// ============================================================
// CONEXIÓN A MYSQL
// ============================================================

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'control_empleados',
    port: process.env.DB_PORT || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

const db = pool.promise();

// ============================================================
// MIDDLEWARE DE AUTENTICACIÓN
// ============================================================

function verificarSesion(req, res, next) {
    if (req.session.usuario) {
        next();
    } else {
        res.status(401).json({ error: 'No autorizado' });
    }
}

function verificarAdmin(req, res, next) {
    if (req.session.usuario && req.session.usuario.rol === 'admin') {
        next();
    } else {
        res.status(403).json({ error: 'Acceso denegado. Se requiere rol admin' });
    }
}

// ============================================================
// RUTAS API
// ============================================================

// ---------- RUTA: Login ----------
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Usuario y contraseña son requeridos' });
    }

    try {
        const [rows] = await db.query(
            `SELECT u.*, e.nombre, e.apellido 
             FROM usuarios u 
             LEFT JOIN empleados e ON u.empleado_id = e.id 
             WHERE u.username = ? AND u.password = ? AND u.activo = 1`,
            [username, password]
        );

        if (rows.length > 0) {
            const usuario = rows[0];
            req.session.usuario = {
                id: usuario.id,
                username: usuario.username,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                rol: usuario.rol,
                empleado_id: usuario.empleado_id
            };
            res.json({ 
                success: true, 
                usuario: req.session.usuario 
            });
        } else {
            res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
        }
    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

// ---------- RUTA: Verificar sesión ----------
app.get('/api/sesion', (req, res) => {
    if (req.session.usuario) {
        res.json({ autenticado: true, usuario: req.session.usuario });
    } else {
        res.json({ autenticado: false });
    }
});

// ---------- RUTA: Logout ----------
app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

// ---------- RUTAS: EMPLEADOS ----------

// GET - Listar todos los empleados
app.get('/api/empleados', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT e.*, a.nombre AS area_nombre 
             FROM empleados e 
             LEFT JOIN areas a ON e.area_id = a.id 
             WHERE e.activo = 1 
             ORDER BY e.apellido, e.nombre`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error al listar empleados:', error);
        res.status(500).json({ error: 'Error al obtener empleados' });
    }
});

// GET - Obtener un empleado por ID
app.get('/api/empleados/:id', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT e.*, a.nombre AS area_nombre 
             FROM empleados e 
             LEFT JOIN areas a ON e.area_id = a.id 
             WHERE e.id = ?`,
            [req.params.id]
        );
        
        if (rows.length > 0) {
            res.json(rows[0]);
        } else {
            res.status(404).json({ error: 'Empleado no encontrado' });
        }
    } catch (error) {
        console.error('Error al obtener empleado:', error);
        res.status(500).json({ error: 'Error al obtener empleado' });
    }
});

// GET - Buscar empleados
app.get('/api/empleados/buscar/:termino', verificarSesion, async (req, res) => {
    const termino = req.params.termino;
    try {
        const [rows] = await db.query(
            `SELECT e.*, a.nombre AS area_nombre 
             FROM empleados e 
             LEFT JOIN areas a ON e.area_id = a.id 
             WHERE e.activo = 1 
             AND (e.nombre LIKE ? OR e.apellido LIKE ? OR e.dni LIKE ?)
             ORDER BY e.apellido, e.nombre`,
            [`%${termino}%`, `%${termino}%`, `%${termino}%`]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error al buscar empleados:', error);
        res.status(500).json({ error: 'Error al buscar empleados' });
    }
});

// POST - Crear empleado
app.post('/api/empleados', verificarSesion, async (req, res) => {
    const { nombre, apellido, dni, fecha_nac, cargo, salario, fecha_ingreso, email, telefono, direccion, area_id } = req.body;

    if (!nombre || !apellido || !dni || !fecha_ingreso) {
        return res.status(400).json({ error: 'Nombre, apellido, DNI y fecha de ingreso son obligatorios' });
    }

    try {
        // Verificar DNI único
        const [existe] = await db.query('SELECT id FROM empleados WHERE dni = ?', [dni]);
        if (existe.length > 0) {
            return res.status(400).json({ error: 'El DNI ya existe' });
        }

        const [result] = await db.query(
            `INSERT INTO empleados 
             (nombre, apellido, dni, fecha_nac, cargo, salario, fecha_ingreso, email, telefono, direccion, area_id) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [nombre, apellido, dni, fecha_nac || null, cargo || null, salario || 0, fecha_ingreso, email || null, telefono || null, direccion || null, area_id || null]
        );

        res.status(201).json({ 
            success: true, 
            id: result.insertId,
            message: 'Empleado creado exitosamente' 
        });
    } catch (error) {
        console.error('Error al crear empleado:', error);
        res.status(500).json({ error: 'Error al crear empleado' });
    }
});

// PUT - Actualizar empleado
app.put('/api/empleados/:id', verificarSesion, async (req, res) => {
    const { nombre, apellido, dni, fecha_nac, cargo, salario, fecha_ingreso, email, telefono, direccion, area_id } = req.body;
    const id = req.params.id;

    try {
        // Verificar DNI único (excepto el actual)
        const [existe] = await db.query('SELECT id FROM empleados WHERE dni = ? AND id != ?', [dni, id]);
        if (existe.length > 0) {
            return res.status(400).json({ error: 'El DNI ya existe' });
        }

        await db.query(
            `UPDATE empleados 
             SET nombre = ?, apellido = ?, dni = ?, fecha_nac = ?, cargo = ?, salario = ?, 
                 fecha_ingreso = ?, email = ?, telefono = ?, direccion = ?, area_id = ? 
             WHERE id = ?`,
            [nombre, apellido, dni, fecha_nac || null, cargo || null, salario || 0, fecha_ingreso, email || null, telefono || null, direccion || null, area_id || null, id]
        );

        res.json({ success: true, message: 'Empleado actualizado exitosamente' });
    } catch (error) {
        console.error('Error al actualizar empleado:', error);
        res.status(500).json({ error: 'Error al actualizar empleado' });
    }
});

// DELETE - Desactivar empleado (eliminación lógica)
app.delete('/api/empleados/:id', verificarSesion, async (req, res) => {
    try {
        await db.query('UPDATE empleados SET activo = 0 WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Empleado desactivado' });
    } catch (error) {
        console.error('Error al desactivar empleado:', error);
        res.status(500).json({ error: 'Error al desactivar empleado' });
    }
});

// DELETE - Eliminar empleado (físico, solo admin)
app.delete('/api/empleados/fisico/:id', verificarAdmin, async (req, res) => {
    try {
        await db.query('DELETE FROM empleados WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Empleado eliminado permanentemente' });
    } catch (error) {
        console.error('Error al eliminar empleado:', error);
        res.status(500).json({ error: 'Error al eliminar empleado' });
    }
});

// ---------- RUTAS: ASISTENCIAS ----------

// POST - Registrar entrada
app.post('/api/asistencias/entrada', verificarSesion, async (req, res) => {
    const { empleado_id } = req.body;

    if (!empleado_id) {
        return res.status(400).json({ error: 'ID de empleado requerido' });
    }

    try {
        // Verificar si ya tiene entrada hoy
        const [existe] = await db.query(
            'SELECT id FROM asistencias WHERE empleado_id = ? AND fecha = CURDATE()',
            [empleado_id]
        );

        if (existe.length > 0) {
            return res.status(400).json({ error: 'El empleado ya tiene entrada registrada hoy' });
        }

        await db.query(
            `INSERT INTO asistencias (empleado_id, fecha, hora_entrada, estado) 
             VALUES (?, CURDATE(), CURTIME(), 'Presente')`,
            [empleado_id]
        );

        res.json({ success: true, message: '✅ Entrada registrada exitosamente' });
    } catch (error) {
        console.error('Error al registrar entrada:', error);
        res.status(500).json({ error: 'Error al registrar entrada' });
    }
});

// PUT - Registrar salida
app.put('/api/asistencias/salida', verificarSesion, async (req, res) => {
    const { empleado_id } = req.body;

    if (!empleado_id) {
        return res.status(400).json({ error: 'ID de empleado requerido' });
    }

    try {
        const [result] = await db.query(
            `UPDATE asistencias 
             SET hora_salida = CURTIME() 
             WHERE empleado_id = ? AND fecha = CURDATE() AND hora_entrada IS NOT NULL`,
            [empleado_id]
        );

        if (result.affectedRows === 0) {
            return res.status(400).json({ error: 'No se encontró entrada para hoy' });
        }

        res.json({ success: true, message: '✅ Salida registrada exitosamente' });
    } catch (error) {
        console.error('Error al registrar salida:', error);
        res.status(500).json({ error: 'Error al registrar salida' });
    }
});

// GET - Asistencias de hoy
app.get('/api/asistencias/hoy', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT a.*, CONCAT(e.nombre, ' ', e.apellido) AS empleado, e.dni 
             FROM asistencias a 
             JOIN empleados e ON a.empleado_id = e.id 
             WHERE a.fecha = CURDATE() 
             ORDER BY a.hora_entrada DESC`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener asistencias de hoy:', error);
        res.status(500).json({ error: 'Error al obtener asistencias' });
    }
});

// GET - Asistencias de un empleado
app.get('/api/asistencias/empleado/:id', verificarSesion, async (req, res) => {
    const dias = req.query.dias || 30;
    try {
        const [rows] = await db.query(
            `SELECT * FROM asistencias 
             WHERE empleado_id = ? 
             AND fecha >= DATE_SUB(CURDATE(), INTERVAL ? DAY) 
             ORDER BY fecha DESC`,
            [req.params.id, dias]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener asistencias del empleado:', error);
        res.status(500).json({ error: 'Error al obtener asistencias' });
    }
});

// GET - Resumen de asistencias de un empleado
app.get('/api/asistencias/resumen/:id', verificarSesion, async (req, res) => {
    const dias = req.query.dias || 30;
    try {
        const [rows] = await db.query(
            `SELECT 
                COUNT(*) AS total,
                SUM(CASE WHEN estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
                SUM(CASE WHEN estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
                SUM(CASE WHEN estado = 'Tarde' THEN 1 ELSE 0 END) AS tardes,
                SUM(CASE WHEN estado = 'Justificado' THEN 1 ELSE 0 END) AS justificados
             FROM asistencias 
             WHERE empleado_id = ? 
             AND fecha >= DATE_SUB(CURDATE(), INTERVAL ? DAY)`,
            [req.params.id, dias]
        );
        res.json(rows[0]);
    } catch (error) {
        console.error('Error al obtener resumen de asistencias:', error);
        res.status(500).json({ error: 'Error al obtener resumen' });
    }
});

// ---------- RUTAS: REPORTES ----------

// GET - Empleados por área (usa la vista)
app.get('/api/reportes/empleados-por-area', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT * FROM v_empleados_por_area`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error en reporte empleados por área:', error);
        res.status(500).json({ error: 'Error al generar reporte' });
    }
});

// GET - Antigüedad de empleados (usa la vista)
app.get('/api/reportes/antiguedad', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT * FROM v_antiguedad`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error en reporte antigüedad:', error);
        res.status(500).json({ error: 'Error al generar reporte' });
    }
});

// GET - Top salarios (usa la vista)
app.get('/api/reportes/top-salarios', verificarSesion, async (req, res) => {
    const limite = req.query.limite || 5;
    try {
        const [rows] = await db.query(
            `SELECT * FROM v_top_salarios`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error en reporte top salarios:', error);
        res.status(500).json({ error: 'Error al generar reporte' });
    }
});

// GET - Estadísticas generales
app.get('/api/reportes/estadisticas', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT 
                (SELECT COUNT(*) FROM empleados WHERE activo = 1) AS total_empleados,
                (SELECT COUNT(*) FROM areas) AS total_areas,
                (SELECT COUNT(*) FROM asistencias WHERE fecha = CURDATE()) AS asistencias_hoy,
                (SELECT COUNT(DISTINCT empleado_id) FROM asistencias WHERE fecha = CURDATE()) AS presentes_hoy,
                (SELECT ROUND(AVG(salario), 2) FROM empleados WHERE activo = 1) AS salario_promedio,
                (SELECT MAX(salario) FROM empleados WHERE activo = 1) AS salario_maximo,
                (SELECT MIN(salario) FROM empleados WHERE activo = 1) AS salario_minimo`
        );
        res.json(rows[0]);
    } catch (error) {
        console.error('Error al obtener estadísticas:', error);
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// ---------- RUTAS: ÁREAS ----------

// GET - Listar áreas
app.get('/api/areas', verificarSesion, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM areas ORDER BY nombre');
        res.json(rows);
    } catch (error) {
        console.error('Error al listar áreas:', error);
        res.status(500).json({ error: 'Error al obtener áreas' });
    }
});

// ---------- RUTAS: USUARIOS ----------

// GET - Listar usuarios (solo admin)
app.get('/api/usuarios', verificarAdmin, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT u.*, CONCAT(e.nombre, ' ', e.apellido) AS empleado_nombre 
             FROM usuarios u 
             LEFT JOIN empleados e ON u.empleado_id = e.id 
             ORDER BY u.username`
        );
        res.json(rows);
    } catch (error) {
        console.error('Error al listar usuarios:', error);
        res.status(500).json({ error: 'Error al obtener usuarios' });
    }
});

// POST - Crear usuario (solo admin)
app.post('/api/usuarios', verificarAdmin, async (req, res) => {
    const { empleado_id, username, password, rol } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Usuario y contraseña son requeridos' });
    }

    try {
        const [result] = await db.query(
            `INSERT INTO usuarios (empleado_id, username, password, rol) 
             VALUES (?, ?, ?, ?)`,
            [empleado_id || null, username, password, rol || 'user']
        );

        res.status(201).json({ 
            success: true, 
            id: result.insertId,
            message: 'Usuario creado exitosamente' 
        });
    } catch (error) {
        console.error('Error al crear usuario:', error);
        res.status(500).json({ error: 'Error al crear usuario' });
    }
});

// ---------- RUTA: Servir la página principal ----------
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ============================================================
// INICIAR SERVIDOR
// ============================================================

app.listen(PORT, () => {
    console.log(`✅ Servidor corriendo en: http://localhost:${PORT}`);
    console.log(`📊 Base de datos: control_empleados`);
    console.log(`🔑 Usuario admin: cgonzalez / admin123`);
});