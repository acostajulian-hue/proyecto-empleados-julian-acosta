-- ============================================================
-- NOMBRE: 10_admin_comandos.sql
-- DESCRIPCIÓN: Comandos de administración de la base de datos
-- ============================================================

-- Ver el tamaño de la base de datos
SELECT 
    table_schema AS 'Base de Datos',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Tamaño (MB)'
FROM information_schema.tables
WHERE table_schema = 'control_empleados'
GROUP BY table_schema;

-- Ver las tablas más grandes
SELECT 
    table_name AS 'Tabla',
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Tamaño (MB)'
FROM information_schema.tables
WHERE table_schema = 'control_empleados'
ORDER BY (data_length + index_length) DESC;

-- Ver estadísticas de la base de datos
SELECT 
    (SELECT COUNT(*) FROM empleados) AS empleados,
    (SELECT COUNT(*) FROM areas) AS areas,
    (SELECT COUNT(*) FROM asistencias) AS asistencias,
    (SELECT COUNT(*) FROM usuarios) AS usuarios;

-- Vaciar una tabla
-- TRUNCATE TABLE asistencias;

-- Respaldar estructura (solo estructura, sin datos)
-- mysqldump -u root -p --no-data control_empleados > estructura_bd.sql

-- Respaldar datos (solo datos, sin estructura)
-- mysqldump -u root -p --no-create-info control_empleados > datos_bd.sql