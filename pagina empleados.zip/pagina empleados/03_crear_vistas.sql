-- ============================================================
-- NOMBRE: 03_crear_vistas.sql
-- DESCRIPCIÓN: Todas las vistas del sistema
-- ============================================================

-- Vista 1: Empleados con área y antigüedad
CREATE VIEW v_empleados_area AS
SELECT 
    e.id,
    e.nombre,
    e.apellido,
    e.dni,
    e.cargo,
    e.salario,
    e.fecha_ingreso,
    e.email,
    e.telefono,
    e.direccion,
    a.nombre AS area,
    e.activo,
    DATEDIFF(CURDATE(), e.fecha_ingreso) AS dias_antiguedad
FROM empleados e
LEFT JOIN areas a ON e.area_id = a.id
WHERE e.activo = 1;

-- Vista 2: Resumen de asistencias por empleado
CREATE VIEW v_resumen_asistencias AS
SELECT 
    e.id,
    e.nombre,
    e.apellido,
    COUNT(a.id) AS total_asistencias,
    SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
    SUM(CASE WHEN a.estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
    SUM(CASE WHEN a.estado = 'Tarde' THEN 1 ELSE 0 END) AS tardes,
    SUM(CASE WHEN a.estado = 'Justificado' THEN 1 ELSE 0 END) AS justificados,
    ROUND(
        (SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 2
    ) AS porcentaje_presentismo
FROM empleados e
LEFT JOIN asistencias a ON e.id = a.empleado_id
WHERE e.activo = 1
GROUP BY e.id;

-- Vista 3: Asistencias del día actual
CREATE VIEW v_asistencias_hoy AS
SELECT 
    a.id,
    a.empleado_id,
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.dni,
    e.cargo,
    a.fecha,
    TIME_FORMAT(a.hora_entrada, '%H:%i') AS entrada,
    TIME_FORMAT(a.hora_salida, '%H:%i') AS salida,
    a.estado,
    a.observaciones
FROM asistencias a
JOIN empleados e ON a.empleado_id = e.id
WHERE a.fecha = CURDATE()
ORDER BY a.hora_entrada DESC;

-- Vista 4: Empleados por área (conteo y promedios)
CREATE VIEW v_empleados_por_area AS
SELECT 
    a.id AS area_id,
    a.nombre AS area,
    a.descripcion,
    COUNT(e.id) AS cantidad_empleados,
    ROUND(AVG(e.salario), 2) AS salario_promedio,
    MIN(e.salario) AS salario_minimo,
    MAX(e.salario) AS salario_maximo
FROM areas a
LEFT JOIN empleados e ON a.id = e.area_id AND e.activo = 1
GROUP BY a.id
ORDER BY cantidad_empleados DESC;

-- Vista 5: Top 5 mejores salarios
CREATE VIEW v_top_salarios AS
SELECT 
    e.id,
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.cargo,
    e.salario,
    a.nombre AS area,
    e.fecha_ingreso
FROM empleados e
LEFT JOIN areas a ON e.area_id = a.id
WHERE e.activo = 1 AND e.salario IS NOT NULL
ORDER BY e.salario DESC
LIMIT 5;

-- Vista 6: Antigüedad de empleados
CREATE VIEW v_antiguedad AS
SELECT 
    e.id,
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.cargo,
    e.fecha_ingreso,
    DATEDIFF(CURDATE(), e.fecha_ingreso) AS dias_antiguedad,
    CONCAT(
        FLOOR(DATEDIFF(CURDATE(), e.fecha_ingreso) / 365), 
        ' años, ',
        FLOOR((DATEDIFF(CURDATE(), e.fecha_ingreso) % 365) / 30),
        ' meses'
    ) AS antiguedad_texto,
    a.nombre AS area
FROM empleados e
LEFT JOIN areas a ON e.area_id = a.id
WHERE e.activo = 1
ORDER BY dias_antiguedad DESC;

-- Vista 7: Empleados sin asistencia hoy
CREATE VIEW v_ausentes_hoy AS
SELECT 
    e.id,
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.cargo,
    a.nombre AS area,
    e.email,
    e.telefono
FROM empleados e
LEFT JOIN areas a ON e.area_id = a.id
LEFT JOIN asistencias asis ON e.id = asis.empleado_id AND asis.fecha = CURDATE()
WHERE e.activo = 1 AND asis.id IS NULL;

-- Vista 8: Resumen mensual de asistencias (mes actual)
CREATE VIEW v_asistencias_mes_actual AS
SELECT 
    CONCAT(e.nombre, ' ', e.apellido) AS empleado,
    e.cargo,
    COUNT(a.id) AS total_dias,
    SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
    SUM(CASE WHEN a.estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
    SUM(CASE WHEN a.estado = 'Tarde' THEN 1 ELSE 0 END) AS tardes,
    ROUND(
        (SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 2
    ) AS porcentaje_presentismo
FROM empleados e
LEFT JOIN asistencias a ON e.id = a.empleado_id 
    AND MONTH(a.fecha) = MONTH(CURDATE())
    AND YEAR(a.fecha) = YEAR(CURDATE())
WHERE e.activo = 1
GROUP BY e.id
HAVING total_dias > 0
ORDER BY porcentaje_presentismo DESC;