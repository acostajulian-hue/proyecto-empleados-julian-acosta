-- ============================================================
-- SISTEMA DE CONTROL DE EMPLEADOS
-- EMPRESA: TecnoServicios del Plata S.A.
-- BASE DE DATOS: control_empleados
-- ============================================================

-- ELIMINAR BASE DE DATOS SI EXISTE (para empezar desde cero)
DROP DATABASE IF EXISTS control_empleados;

-- CREAR BASE DE DATOS
CREATE DATABASE control_empleados 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- USAR LA BASE DE DATOS
USE control_empleados;

-- ============================================================
-- 1. TABLA ÁREAS
-- ============================================================
CREATE TABLE areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 2. TABLA EMPLEADOS
-- ============================================================
CREATE TABLE empleados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    dni VARCHAR(15) NOT NULL UNIQUE,
    fecha_nac DATE,
    cargo VARCHAR(50),
    salario DECIMAL(10,2),
    fecha_ingreso DATE NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(20),
    direccion VARCHAR(150),
    area_id INT,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE SET NULL,
    INDEX idx_apellido (apellido),
    INDEX idx_dni (dni)
);

-- ============================================================
-- 3. TABLA ASISTENCIAS
-- ============================================================
CREATE TABLE asistencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT NOT NULL,
    fecha DATE NOT NULL,
    hora_entrada TIME,
    hora_salida TIME,
    estado ENUM('Presente', 'Ausente', 'Justificado', 'Tarde', 'Vacaciones') 
        DEFAULT 'Presente',
    observaciones TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE CASCADE,
    UNIQUE KEY unique_asistencia (empleado_id, fecha),
    INDEX idx_fecha (fecha)
);

-- ============================================================
-- 4. TABLA USUARIOS
-- ============================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'supervisor', 'user') DEFAULT 'user',
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE SET NULL,
    INDEX idx_username (username)
);

-- ============================================================
-- 5. TABLA PARA LOGS (opcional, para auditoría)
-- ============================================================
CREATE TABLE logs_eliminacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50),
    registro_id INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50)
);