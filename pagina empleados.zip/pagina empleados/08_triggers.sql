-- ============================================================
-- NOMBRE: 08_triggers.sql
-- DESCRIPCIÓN: Todos los triggers del sistema
-- ============================================================

-- Trigger 1: Actualizar fecha de modificación en empleados
DELIMITER //

CREATE TRIGGER tr_empleados_before_update
BEFORE UPDATE ON empleados
FOR EACH ROW
BEGIN
    SET NEW.fecha_creacion = NOW();
END //

DELIMITER ;

-- Trigger 2: Log de eliminación de empleados
DELIMITER //

CREATE TRIGGER tr_empleados_before_delete
BEFORE DELETE ON empleados
FOR EACH ROW
BEGIN
    INSERT INTO logs_eliminacion (tabla, registro_id, usuario) 
    VALUES ('empleados', OLD.id, CURRENT_USER());
END //

DELIMITER ;

-- Trigger 3: Verificar DNI único antes de insertar
DELIMITER //

CREATE TRIGGER tr_empleados_before_insert
BEFORE INSERT ON empleados
FOR EACH ROW
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count FROM empleados WHERE dni = NEW.dni;
    IF v_count > 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = '❌ El DNI ya existe en la base de datos';
    END IF;
END //

DELIMITER ;

-- Trigger 4: Validar salario no negativo
DELIMITER //

CREATE TRIGGER tr_empleados_salario_check
BEFORE INSERT ON empleados
FOR EACH ROW
BEGIN
    IF NEW.salario < 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = '❌ El salario no puede ser negativo';
    END IF;
END //

DELIMITER ;

-- Trigger 5: Actualizar estado en asistencias
DELIMITER //

CREATE TRIGGER tr_asistencias_before_insert
BEFORE INSERT ON asistencias
FOR EACH ROW
BEGIN
    IF NEW.hora_entrada IS NULL THEN
        SET NEW.estado = 'Ausente';
    END IF;
END //

DELIMITER ;